#include <stdio.h>
#include <stdlib.h>

int main()
{
    int N[1000];
    int number,i;
    scanf("%d",&number);
    for(i=0; i<1000; i++)
    {
        N[i]=i%number;
    }
    for(i=0; i<1000; i++)
    {
        printf("N[%d] = %d\n",i,N[i]);
    }
}
