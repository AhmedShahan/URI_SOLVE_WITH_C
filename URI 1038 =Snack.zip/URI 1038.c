#include <stdio.h>
#include <stdlib.h>

int main()
{
    int x,y;
    scanf("%d",&x);

    scanf("%d",&y);
    if(x==1)
    {
        printf("Total: R$ %.2f\n",y*4.0);
    }
    else if (x==2)
    {
        printf("Total: R$ %.2f\n",y*4.5);
    }
    else if (x==3)
    {
        printf("Total: R$ %.2f\n",y*5.0);
    }
    else if (x==4)
    {
        printf("Total: R$ %.2f\n",y*2.0);
    }
    else
    {
        printf("Total: R$ %.2f\n",y*1.5);
    }
    return 0;
}
