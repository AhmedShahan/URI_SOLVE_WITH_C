#include <stdio.h>
#include <stdlib.h>

int main()
{
    int iday,ihour,imin,isec,fday,fhour,fmin,fsec,day,hour,min,sec;
    char s1,s2,s3,s4;

    scanf("%*s %d",&iday);
    scanf("%d %c %d %c %d",&ihour,&s1,&imin,&s2,&isec);
    scanf("%*s %d",&fday);
    scanf("%d %c %d %c %d",&fhour,&s3,&fmin,&s4,&fsec);

    sec=fsec-isec;
    if(sec<0)
    {
        sec=60+fsec-isec;
        fmin--;
    }
    min=fmin-imin;
    if(min<0)
    {
        min=60+fmin-imin;
        fhour--;
    }
    hour=fhour-ihour;
    if(hour<0)
    {
        hour=24+fhour-ihour;
        fday--;
    }
    day=fday-iday;
    printf("%d dia(s)\n",day);
    printf("%d hora(s)\n",hour);
    printf("%d minuto(s)\n",min);
    printf("%d segundo(s)\n",sec);

    return 0;
}
