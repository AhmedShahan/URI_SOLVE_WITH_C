#include <stdio.h>
#include <stdlib.h>

int main()
{
    int ihour,imin,fhour,fmin,hour,min,dtime;
    scanf("%d %d %d %d",&ihour,&imin,&fhour,&fmin);

    dtime=(fhour*60+fmin)-(ihour*60+imin);
    if(dtime<=0)
    {
        dtime+=24*60;
    }
    printf("O JOGO DUROU %d HORA(S) E %d MINUTO(S)\n",dtime/60,dtime%60);
    return 0;
}
