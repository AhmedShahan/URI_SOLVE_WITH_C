#include <stdio.h>
#include <stdlib.h>

int main()
{
    char a[20];
    char b[20];
    char c[20];

    gets(a);
    gets(b);
    gets(c);

    if(a[0]=='v')
    {
        if(b[0]=='a')
        {
            if(c[0]=='c')
            {
                printf("aguia\n");
            }
            else
            {
                printf("pomba\n");
            }
        }
        if(b[0]=='m')
        {
            if(c[0]=='o')
            {
                printf("homem\n");
            }
            else
            {
                printf("vaca\n");
            }
        }
    }
    else
    {
        if(b[0]=='i')
        {
            if(c[2]=='m')
            {
                printf("pulga\n");
            }
            else
            {
                printf("lagarta\n");
            }
        }
        else if(b[0]=='a')
        {
            if(c[0]=='h')
            {
                printf("sanguessuga\n");
            }
            else
            {
                printf("minhoca\n");
            }
        }
    }
    return 0;
}
