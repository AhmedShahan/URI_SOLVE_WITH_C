#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a,b,i;
    scanf("%d %d",&a,&b);

    if(b>a)
    {
        for(i=a+1; i<b; i++)
        {
            if(i%5==2 || i%5==3)
            {
                printf("%d\n",i);
            }
        }
    }
    else
    {
        for(i=b+1; i<a; i++)
        {
            if(i%5==2 || i%5==3)
            {
                printf("%d\n",i);
            }
        }
    }
    return 0;
}
