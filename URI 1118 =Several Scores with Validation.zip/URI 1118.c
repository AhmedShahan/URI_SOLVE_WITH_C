#include <stdio.h>
#include <stdlib.h>
void avrg()
{
    double a,flag=0,sum=0;
    while(flag!=2.0)
    {
        scanf("%lf",&a);
        if(a<0 || a>10)
        {
            printf("nota invalida\n");
        }
        else
        {
            sum=sum+a;
            flag++;
        }
    }
    printf("media = %.2lf\n",sum/2.0);
    sum=0;
}

int main()
{
    avrg();
    float a;
    while(a!=2)
    {
        printf("novo calculo (1-sim 2-nao)\n");
        scanf("%f",&a);
        if(a==1.0)
        {
            avrg();
        }
    }
    return 0;
}
