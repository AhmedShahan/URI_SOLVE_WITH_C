#include <stdio.h>
#include <stdlib.h>
void operation()
{
    int pa,pb,flag=0;
    double ga,gb;
    scanf("%d %d %lf %lf",&pa,&pb,&ga,&gb);

    while(pa<=pb)
    {
        pa=pa+(pa*ga/100.0);
        pb=pb+(pb*gb/100.0);
        flag++;
        if(flag>100)
        {
            printf("Mais de 1 seculo.\n");
            break;
        }
    }
    if(flag<=100)
    {
        printf("%d anos.\n",flag);
    }
}
int main()
{
    int n;
    scanf("%d",&n);

    int i=0;
    while(i!=n)
    {
        operation();
        i++;
    }

}
