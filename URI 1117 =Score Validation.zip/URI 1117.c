#include <stdio.h>
#include <stdlib.h>

int main()
{
    float a,flag=0,sum=0,res;

    while(flag!=2)
    {
        scanf("%f",&a);
        if(a<0 || a>10)
        {
            printf("nota invalida\n");
        }
        else
        {
            sum=sum+a;
            flag++;
        }
    }
    res=sum/2.0;
    printf("media = %.2f\n",res);
}
