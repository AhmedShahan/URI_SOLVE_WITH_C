#include <stdio.h>
#include <stdlib.h>

int main()
{
    int dIn,year,i,month,dOut;
    scanf("%d",&dIn);
    year=dIn/365;
    i=dIn%365;
    month=i/30;
    dOut=i%30;
    printf("%d ano(s)\n",year);
    printf("%d mes(es)\n",month);
    printf("%d dia(s)\n",dOut);
    return 0;
}
