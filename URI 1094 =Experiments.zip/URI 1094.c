#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n,in,total=0,cat=0,rat=0,sat=0;
    char k[2];
    scanf("%d",&n);
    int i;
    for(i=1; i<=n; i++)
    {
        scanf("%d %s",&in,&k);
        total=total+in;
        if(k[0]=='c'|| k[0]=='C')
        {
            cat=cat+in;
        }
        else if(k[0]=='s'||k[0]=='S')
        {
            sat=sat+in;
        }
        else
        {
            rat=rat+in;
        }
    }
    double resC,resR,resS;
    resC=(float)cat*100.0/(float)total;
    resR=(float)rat*100.0/(float)total;
    resS=(float)sat*100.0/(float)total;
    printf("Total: %d cobaias\n",total);
    printf("Total de coelhos: %d\n",cat);
    printf("Total de ratos: %d\n",rat);
    printf("Total de sapos: %d\n",sat);
    printf("Percentual de coelhos: %.2lf %%\n",resC);
    printf("Percentual de ratos: %.2lf %%\n",resR);
    printf("Percentual de sapos: %.2lf %%\n",resS);
    return 0;
}
