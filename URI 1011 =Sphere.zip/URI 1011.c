#include <stdio.h>
#include <stdlib.h>

int main()
{
    double R,Pi,VOLUME;
    Pi=3.14159;
    scanf("%lf",&R);
    VOLUME=(4.0/3)*Pi*R*R*R;
    printf("VOLUME = %.3lf\n",VOLUME);
    return 0;
}
