#include <stdio.h>
#include <math.h>
void sum(int A, int B);
void sub(int A, int B);
void mult(int A, int B);
void div(int A, int B);
void simple(int A, int B);
int main()
{
    int input,i,n1,n2,d1,d2,a,b,c;
    char c1,c2,ope;
    scanf("%d",&input);
    for(i=1; i<=input; i++)
    {
        scanf("%d %c %d %c %d %c %d",&n1,&c1,&d1,&ope,&n2,&c2,&d2);
        a=n1*d2;
        b=n2*d1;
        c=d1*d2;

        switch(ope)
        {
            case '+':
            {
                sum(a+b,c);
                break;
            }
            case '-':
            {
                sub(a-b,c);
                break;
            }
            case '*':
            {
                mult(n1*n2,c);
                break;
            }
            case '/':
            {
                div(a,b);
                break;
            }
        }
        a=0;
        b=0;
        c=0;
    }
}


void sum(int A, int B)
{
    printf("%d/%d = ",A,B);
    simle(A,B);
}

void sub(int A, int B)
{
    printf("%d/%d = ",A,B);
    simle(A,B);
}

void mult(int A, int B)
{
    printf("%d/%d = ",A,B);
    simle(A,B);
}
void div(int A, int B)
{
    printf("%d/%d = ",A,B);
    simle(A,B);
}

void simle(int A, int B)
{
    int i,j=2;
    if(A>B)
    {
        while(j<=abs(B))
        {
            if(A%j==0 && B%j==0)
            {
                A=A/j;
                B=B/j;
            }
            else
            {
                j++;
            }
        }
    }

    else
    {
        while(j<=abs(A))
        {
            if(A%j==0 && B%j==0)
            {
                A=A/j;
                B=B/j;
            }
            else
            {
                j++;
            }
        }
    }
    printf("%d/%d\n",A,B);
}


