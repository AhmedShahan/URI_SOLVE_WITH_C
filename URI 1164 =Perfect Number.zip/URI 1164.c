#include <stdio.h>
#include <stdlib.h>
int main()
{
    int n,a,i,j,sum=0;
    scanf("%d",&n);

    for(j=1; j<=n; j++)
    {
        scanf("%d",&a);
        int b=a;
    for(i=1; i<b; i++)
    {
        if(b%i==0)
        {
            sum=sum+i;
        }
    }
    if(a==sum)
    {
        printf("%d eh perfeito\n",a);
    }
    else
    {
        printf("%d nao eh perfeito\n",a);
    }
    sum=0;
    }

    return 0;
}
