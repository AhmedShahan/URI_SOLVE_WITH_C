#include <stdio.h>
#include <stdlib.h>
///S=(1 +3/2 + 5/4 + 7/8 + 9/16 + 11/32)
int main()
{
    double i,j,sum=0;
    for(i=1,j=1; i<=39; i=i+2,j=j*2)
    {
        sum=sum+(i/j);
    }
    printf("%.2lf\n",sum);
}
