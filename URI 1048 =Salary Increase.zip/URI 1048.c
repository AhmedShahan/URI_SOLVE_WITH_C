#include <stdio.h>
#include <stdlib.h>

int main()
{
    float sal,parcent,res;

    scanf("%f",&sal);

    if(sal>=0.00 && sal<=400.00)
    {
        parcent=(sal*15.0)/100.0;
        res=sal+parcent;
        printf("Novo salario: %.2f\n",res);
        printf("Reajuste ganho: %.2f\n",parcent);
        printf("Em percentual: 15 %%\n");
    }
    else if(sal>=400.01 && sal<=800.00)
    {
        parcent=(sal*12.0)/100.0;
        res=sal+parcent;
        printf("Novo salario: %.2f\n",res);
        printf("Reajuste ganho: %.2f\n",parcent);
        printf("Em percentual: 12 %%\n");
    }

    else if(sal>=800.01 && sal<=1200.00)
    {
        parcent=(sal*10.0)/100.0;
        res=sal+parcent;
        printf("Novo salario: %.2f\n",res);
        printf("Reajuste ganho: %.2f\n",parcent);
        printf("Em percentual: 10 %%\n");
    }
    else if(sal>=1200.01 && sal<=2000.00)
    {
        parcent=(sal*7.0)/100.0;
        res=sal+parcent;
        printf("Novo salario: %.2f\n",res);
        printf("Reajuste ganho: %.2f\n",parcent);
        printf("Em percentual: 7 %%\n");
    }
    else
    {
        parcent=(sal*4.0)/100.0;
        res=sal+parcent;
        printf("Novo salario: %.2f\n",res);
        printf("Reajuste ganho: %.2f\n",parcent);
        printf("Em percentual: 4 %%\n");
    }
    return 0;
}
