#include <stdio.h>
#include <stdlib.h>

int main()
{
    int x;
    float y,resu;
    scanf("%d %f",&x,&y);
    resu=x/y;
    printf("%.3f km/l\n",resu);
    return 0;
}
