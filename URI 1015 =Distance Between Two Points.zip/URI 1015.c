#include <stdio.h>
#include <stdlib.h>

int main()
{
    double x1,x2,y1,y2,X,Y,A,B,distance;
    scanf("%lf",&x1);
    scanf("%lf",&y1);
    scanf("%lf",&x2);
    scanf("%lf",&y2);
    X=x2-x1;
    Y=y2-y1;
    A=pow(X,2);
    B=pow(Y,2);
    distance= sqrt(A+B);
    printf("%.4lf\n",distance);
    return 0;
}
