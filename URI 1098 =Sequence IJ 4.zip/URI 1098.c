#include<stdio.h>
int main()
{
    float i,j;
    for(i=0.0; i<=2.1; i=i+0.2)
    {
        for(j=1.0; j<=3.0; j++)
        {
            if(i==0.0 || i==1.0 || i>=2.0)
            {
                printf("I=%d J=%d\n",(int)i,(int)i+(int)j);
            }
            else
            {
                printf("I=%.1f J=%.1f\n",i,i+j);
            }
        }
    }
    return 0;
}
