#include <stdio.h>
#include <stdlib.h>

float weightavg(float a,float b,float c)
{
    float avrg=(a*2+b*3+c*5)/10.0;
    return avrg;
}

int main()
{
    int n,o;
    float i,j,k;
    scanf("%d",&n);

    for(o=1; o<=n; o++)
    {
        scanf("%f %f %f",&i,&j,&k);
        printf("%.1f\n",weightavg(i,j,k));
    }

}
