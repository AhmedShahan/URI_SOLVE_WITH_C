#include <stdio.h>
#include <stdlib.h>

int main()
{
    double A[12][12];
    char ch[5];
    gets(ch);
    int i,j;
    for(i=0; i<12; i++)
    {
        for(j=0; j<12; j++)
        {
            scanf("%lf",&A[i][j]);
        }
    }

    int k=0,l=11,count=0;
    double sum=0;
    for(i=k; i<5; i++)
    {
        for(j=i+1; j<l; j++)
        {
            sum=sum+A[i][j];
            count++;
        }
        k++;
        l--;
    }

    if(ch[0]=='S')
    {
        printf("%.1lf\n",sum);
    }
    else if(ch[0]=='M')
    {
        printf("%.1lf\n",sum/(float)count);
    }
}
