#include <stdio.h>
#include <stdlib.h>
int sum(int a)
{
    int count=0,sum=0;
    while(count!=5)
    {
        if(a%2==0)
        {
            sum=sum+a;
            count++;
        }
        a++;
    }
    printf("%d\n",sum);
}
int main()
{
    int i;
    while(1)
    {
        scanf("%d",&i);
        if(i==0)
        {
            break;
        }
        else
        {
            sum(i);
        }
    }
}
