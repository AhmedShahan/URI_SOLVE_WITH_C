#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n;
    scanf("%d",&n);
    int i=0,k,j=-3;
    while(i!=n)
    {
        j=j+4;
        for(k=j; k<=j+2; k++)
        {
            printf("%d ",k);
        }
        printf("PUM");
        printf("\n");
        i++;
    }


}
