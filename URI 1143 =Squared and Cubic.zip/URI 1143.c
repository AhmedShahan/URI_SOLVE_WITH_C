#include <stdio.h>
#include <stdlib.h>
#include <math.h>
///Reminder: Never Space after last digit.
int main()
{
    int n;
    scanf("%d",&n);
    int row,col;

    for(row=1; row<=n; row++)
    {
        printf("%d",row);
        for(col=2; col<=3; col++)
        {
            printf(" %d",(int)pow(row,col));
        }
        printf("\n");
    }
}
