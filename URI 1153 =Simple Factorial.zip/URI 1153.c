#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n,i,fect=1;
    scanf("%d",&n);
    for(i=1; i<=n; i++)
    {
        fect=fect*i;
    }
    printf("%d\n",fect);
    return 0;
}
