#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n,a,b,i;
    scanf("%d",&n);

    for(i=1; i<=n; i++)
    {
        scanf("%d %d",&a,&b);
        if(b==0)
            printf("divisao impossivel\n");
        else if (a==0)
            printf("0.0\n");
        else
            printf("%.1f\n",(float)a/(float)b);
    }
    return 0;
}
