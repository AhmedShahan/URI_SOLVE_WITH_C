#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a,b;
    scanf("%d %d",&a,&b);

    int i=1;
    while(i!=b+1)
    {
        printf("%d",i);
        if(i%a==0)
        {
            printf("\n");
        }
        else
        {
            printf(" ");
        }
        i++;
    }
}
