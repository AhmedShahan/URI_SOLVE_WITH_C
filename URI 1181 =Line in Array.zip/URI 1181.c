#include <stdio.h>
#include <stdlib.h>

int main()
{
    double Arr[12][12];
    double sum=0.0,avrg;
    int i,j,number;
    char ch[2];
    scanf("%d",&number);
    fflush(stdin);
    scanf("%s",&ch);
    for(i=0; i<12; i++)
    {
        for(j=0; j<12; j++)
        {
            scanf("%lf",&Arr[i][j]);
        }
    }

    for(i=0; i<12; i++)
    {
        sum=sum+Arr[number][i];
    }
    if(ch[0]=='S')
    {
        printf("%.1lf\n",sum);
    }
    else if(ch[0]=='M')
    {
        printf("%.1lf\n",sum/12.0);
    }
}
