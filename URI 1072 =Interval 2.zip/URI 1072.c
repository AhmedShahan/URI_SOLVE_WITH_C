#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n,i,countIn=0,a;
    scanf("%d",&n);

    for(i=1; i<=n; i++)
    {
        scanf("%d",&a);
        if(a>=10 && a<=20)
        {
            countIn++;
        }
    }
    printf("%d in\n",countIn);
    printf("%d out\n",n-countIn);

    return 0;
}
