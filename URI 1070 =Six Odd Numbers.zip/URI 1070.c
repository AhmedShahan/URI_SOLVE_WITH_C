#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n,i,j;
    scanf("%d",&n);

    if(n%2==0)
    {
        for(i=n+1; i<=12+n; i=i+2)
        {
            printf("%d\n",i);
        }
    }
    else
    {
        for(j=n+2; j<=12+n; j=j+2)
        {
            printf("%d\n",j);
        }
    }
    return 0;
}
