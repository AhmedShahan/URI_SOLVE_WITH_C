#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a,sum=0,count=0;
    while(1)
    {
        scanf("%d",&a);
        if(a<0)
        {
            break;
        }
        else
        {
            sum=sum+a;
            count++;
        }
    }
    printf("%.2f\n",(float)sum/(float)count);
    return 0;
}
