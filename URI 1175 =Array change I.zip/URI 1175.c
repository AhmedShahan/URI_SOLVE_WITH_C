#include <stdio.h>
#include <stdlib.h>

int main()
{
    int N[20];
    int i;
    for(i=0; i<20; i++)
    {
        scanf("%d",&N[i]);
    }

    for(i=0; i<20; i++)
    {
        printf("N[%d] = %d\n",i,N[19-i]);
    }
}
