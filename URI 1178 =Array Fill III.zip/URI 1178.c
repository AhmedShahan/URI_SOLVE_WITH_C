#include <stdio.h>
#include <stdlib.h>
///Variable MUST BE IN DOUBLE OTHERWISE 10% Wrong
int main()
{
    double Arr[100];
    int i;
    double input;
    scanf("%lf",&input);
    printf("N[0] = %.4lf\n",input);
    for(i=1; i<100; i++)
    {
        Arr[i]=input/2.0;
        input=input/2.0;
    }
    for(i=1; i<100; i++)
    {
        printf("N[%d] = %.4lf\n",i,Arr[i]);
    }
}
