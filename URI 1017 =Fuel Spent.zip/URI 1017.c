#include <stdio.h>
#include <stdlib.h>

int main()
{
    int x,y;
    double res;
    scanf("%d %d",&x,&y);
    res=(double)x*y/12;
    printf("%.3lf\n",res);
    return 0;
}
