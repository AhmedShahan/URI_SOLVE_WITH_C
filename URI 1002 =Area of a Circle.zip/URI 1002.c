#include <stdio.h>
#include <stdlib.h>

int main()
{
    double A,R,n;
    n= 3.14159;
    scanf("%lf",&R);
    A=n*R*R;
    printf("A=%.4lf\n",A);
    return 0;
}
