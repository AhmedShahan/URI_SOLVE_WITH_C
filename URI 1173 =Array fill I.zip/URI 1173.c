#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n,i;
    scanf("%d",&n);
    int arr[10];

    for(i=0; i<10; i++)
    {
        printf("N[%d] = %d\n",i,n);
        n=n*2;
    }
    return 0;
}
