#include <stdio.h>
#include <stdlib.h>

int main()
{
    int N[1000];
    int number,i,j,pos=0;
    scanf("%d",&number);

    for(i=0; i<number; i++)
    {
        scanf("%d",&N[i]);
    }
    int small=N[0];
    for(i=0; i<number; i++)
    {
        if(small>N[i])
        {
            small=N[i];
            pos=i;
        }
    }
    printf("Menor valor: %d\n",small);
    printf("Posicao: %d\n",pos);
}
