#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a,b;
    scanf("%d",&a);
    while(1)
    {
        scanf("%d",&b);
        if(b>0)
        {
            break;
        }
    }
    int i,sum;
    sum=a;
    for(i=1; i<b; i++)
    {
        sum=sum+(a+i);
    }
    printf("%d\n",sum);

}
