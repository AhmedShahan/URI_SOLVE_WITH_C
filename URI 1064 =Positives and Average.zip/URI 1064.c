#include <stdio.h>
#include <stdlib.h>

int main()
{
    double a,b,c,d,e,f,sum=0,result;
    int count=0;
    scanf("%lf %lf %lf %lf %lf %lf",&a,&b,&c,&d,&e,&f);

    if(a>0)
    {
        count=count+1;
        sum=sum+a;
    }
    if(b>0.0)
    {
        count=count+1;
        sum=sum+b;
    }
    if(c>0.0)
    {
        count=count+1;
        sum=sum+c;
    }
    if(d>0.0)
    {
        count=count+1;
        sum=sum+d;
    }
    if(e>0.0)
    {
        count=count+1;
        sum=sum+e;
    }
    if(f>0.0)
    {
        count=count+1;
        sum=sum+f;
    }

    result=sum/(float)count;

    printf("%d valores positivos\n",count);
    printf("%.1f\n",result);
    return 0;
}
