#include <stdio.h>
#include <stdlib.h>
///Not store 15 integer in a array
///even or odd array must in 5 size.
///Don't output all in one output. Thats means that when Even Array will fill up. Print this.

int main()
{
    int n,i,j,k,e=0,o=0,even[5],odd[5];

    for(i=0; i<15; i++)
    {
        scanf("%d",&n);
        if(n%2==0)
        {
           even[e]=n;
           e++;
           if(e==5)
           {
               for(j=0; j<5; j++)
               {
                   printf("par[%d] = %d\n",j,even[j]);
                   even[j]=0;
                   e=0;
               }
           }
        }
        else
           {
               odd[o]=n;
                o++;
           if(o==5)
           {
               for(j=0; j<5; j++)
               {
                   printf("impar[%d] = %d\n",j,odd[j]);
                   odd[j]=0;
                   o=0;
               }
           }
           }
        }

        for(k=0;k<o; k++)
           {
               printf("impar[%d] = %d\n",k,odd[k]);
           }
           for(k=0;k<e; k++)
           {
               printf("par[%d] = %d\n",k,even[k]);
           }
    }

