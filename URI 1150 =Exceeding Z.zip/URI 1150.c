#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a,x,sum=0,flag=0;
    scanf("%d",&a);
    while(1)
    {
        scanf("%d",&x);
        if(x>a)
        {
            break;
        }
    }

    int i;
    for(i=a; i<=x; i++)
    {
        sum=sum+i;
        flag++;
        if(sum>x)
        {
            break;
        }
    }
    printf("%d\n",flag);
}
