#include <stdio.h>
#include <stdlib.h>

int main()
{
    double a,b,c,d,R1,R2,dic,sdic;
    scanf("%lf %lf %lf",&a,&b,&c);
    dic=(b*b)-(4*a*c);
    sdic=sqrt(dic);
    if(a!=0 && dic>=0)
    {
        R1=(-b+sdic)/(2*a);
        printf("R1 = %.5lf\n",R1);

        R2= (-b-sdic)/(2*a);
        printf("R2 = %.5lf\n",R2);
    }
    else
        printf("Impossivel calcular\n");
    return 0;
}
