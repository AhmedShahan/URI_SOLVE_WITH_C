#include <stdio.h>
#include <stdlib.h>

int main()
{
    double sum=0;
    double i;
    for(i=1.0; i<=100.0; i++)
    {
        sum=sum+(1.0/i);
    }
    printf("%.2lf\n",sum);
}
