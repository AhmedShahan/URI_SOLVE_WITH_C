#include <stdio.h>
#include <stdlib.h>

int main()
{
    char a[100];
    double fixedsalary,overallsell,TOTAL;
    scanf("%s",&a);
    scanf("%lf %lf",&fixedsalary,&overallsell);
    TOTAL=fixedsalary+(overallsell*0.15);
    printf("TOTAL = R$ %.2lf\n",TOTAL);
    return 0;
}
