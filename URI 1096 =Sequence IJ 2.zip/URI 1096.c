#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a=1;
    while(a<=9)
    {
        int i=a,j=7;
        while(j>=5)
        {
        printf("I=%d J=%d\n",i,j);
        j--;
        }
        a=a+2;
    }

}
