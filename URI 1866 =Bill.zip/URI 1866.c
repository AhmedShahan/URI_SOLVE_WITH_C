#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n;
    scanf("%d",&n);

    int i=0,sum=0;
    while(i!=n)
    {
        int in;
        scanf("%d",&in);
        if(in%2==0)
        {
            printf("0\n");
        }
        else
        {
            printf("1\n");
        }
        i++;
    }
}
