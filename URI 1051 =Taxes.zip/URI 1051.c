#include <stdio.h>
#include <stdlib.h>

int main()
{
    float a,res;
    scanf("%f",&a);
    if(a<=2000.0)
    {
        printf("Isento\n");
    }
    else if(a>=2000.01 && a<=3000.0)
    {
        res=a-2000.0;
        printf("R$ %.2f\n",res*(8.0/100.0));
    }
    else if(a>=3000.0 && a<=4500.0)
    {
        res=a-3000.0;
        printf("R$ %.2f\n",res*(18.0/100.0)+80.0);
    }
    else
    {
        res=a-4500.0;
        printf("R$ %.2f\n",res*(28.0/100.0)+80.0+270.0);
    }
    return 0;
}
