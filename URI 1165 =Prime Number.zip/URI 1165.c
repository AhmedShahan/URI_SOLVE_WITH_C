#include <stdio.h>
#include <string.h>
int main()
{
    int n,a,i,j,count=0;
    scanf("%d",&n);

   for(i=1; i<=n; i++)
   {
       scanf("%d",&a);
       for(j=2; j<a; j++)
       {
           if(a%j==0)
           {
               count++;
               break;
           }
       }
       if(count==0)
       {
           printf("%d eh primo\n",a);
       }
       else
       {
           printf("%d nao eh primo\n",a);
       }
       count=0;
   }

}
