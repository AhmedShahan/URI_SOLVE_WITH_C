#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a,alc=0,ges=0,dis=0;
    while(a!=4)
    {
        scanf("%d",&a);
        if(a>0 && a<=4)
        {
        if(a==1)
        {
            alc++;
        }
        else if(a==2)
        {
            ges++;
        }
        else if(a==3)
        {
            dis++;
        }
        }
    }
    printf("MUITO OBRIGADO\n");
    printf("Alcool: %d\n",alc);
    printf("Gasolina: %d\n",ges);
    printf("Diesel: %d\n",dis);
}
