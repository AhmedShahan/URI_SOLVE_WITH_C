#include <stdio.h>
#include <stdlib.h>

int main()
{
    int Arr[10];
    int i;
    for (i=0; i<10; i++)
    {
        scanf("%d",&Arr[i]);
    }

    for(i=0; i<10; i++)
    {
        if(Arr[i]<=0)
        {
            printf("X[%d] = 1\n",i);
        }
        else
        {
            printf("X[%d] = %d\n",i,Arr[i]);
        }
    }
    return 0;
}
