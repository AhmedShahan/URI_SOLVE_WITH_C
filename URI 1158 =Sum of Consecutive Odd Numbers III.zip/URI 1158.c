#include <stdio.h>
#include <stdlib.h>
void sum()
{
    int a,b,sum=0,count=0;
    scanf("%d %d",&a,&b);
    while(count!=b)
    {
        if(a%2!=0)
        {
            sum=sum+a;
            count++;
        }
        a++;
    }
    printf("%d\n",sum);
    sum=0;
}

int main()
{
    int n;
    scanf("%d",&n);
    int i=0;
    while(i!=n)
    {

        sum();
        i++;
    }
}
