#include <stdio.h>
#include <stdlib.h>

int main()
{
    double A[12][12];
    char ch[5];
    gets(ch);
    int i,j,count=0;
    for(i=0; i<12; i++)
    {
        for(j=0; j<12; j++)
        {
            scanf("%lf",&A[i][j]);
        }
    }

    double sum=0;
    for(i=1; i<6; i++)
    {
        for(j=0; j<i; j++)
        {
            sum=sum+A[i][j];
            count++;
        }
    }

    for(i=10; i>5; i--)
    {
        for(j=0; j<11-i; j++)
        {
            sum=sum+A[i][j];
            count++;
        }
    }
    if(ch[0]=='S')
    {
        printf("%.1lf\n",sum);
    }
    else if(ch[0]=='M')
    {
        printf("%.1lf\n",sum/(float)count);
    }
}
