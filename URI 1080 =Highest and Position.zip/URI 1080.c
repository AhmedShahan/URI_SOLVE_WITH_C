#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a[100],i,j,position=-1;
    for(i=0; i<100; i++)
    {
        scanf("%d",&a[i]);
    }
    int highest=a[0];
    for(i=1; i<100; i++)
    {
        if(highest<a[i])
        {
            highest=a[i];
        }
    }
    printf("%d\n",highest);
    for(j=0; j<100; j++)
    {
        if(highest==a[j])
        {
            position=j+1;
            break;
        }
    }
    printf("%d\n",position);
    return 0;
}
