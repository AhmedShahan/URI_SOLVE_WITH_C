#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a,b,c,d,e,countEven=0,countOdd=0,countPos=0,countNeg=0;
    scanf("%d %d %d %d %d",&a,&b,&c,&d,&e);

    if(a%2==0)
    {
        countEven++;
    }
    if(b%2==0)
    {
        countEven++;
    }
    if(c%2==0)
    {
        countEven++;
    }
    if(d%2==0)
    {
        countEven++;
    }
    if(e%2==0)
    {
        countEven++;
    }
    countOdd=5-countEven;
    printf("%d valor(es) par(es)\n",countEven);
    printf("%d valor(es) impar(es)\n",countOdd);

    if(a>0)
    {
        countPos++;
    }
    if(b>0)
    {
        countPos++;
    }
    if(c>0)
    {
        countPos++;
    }
    if(d>0)
    {
        countPos++;
    }
    if(e>0)
    {
        countPos++;
    }
    printf("%d valor(es) positivo(s)\n",countPos);
    if(a<0)
    {
        countNeg++;
    }
    if(b<0)
    {
        countNeg++;
    }
    if(c<0)
    {
        countNeg++;
    }
    if(d<0)
    {
        countNeg++;
    }
    if(e<0)
    {
        countNeg++;
    }
    printf("%d valor(es) negativo(s)\n",countNeg);
    return 0;
}
