#include <stdio.h>
#include <stdlib.h>

int main()

{
    int a,b,i,sum=0;
    scanf("%d %d",&a,&b);

    if(a>b && b<0)
    {
        for(i=b+1; i<a; i++)
        {
            if(i%2!=0)
            {
                sum=sum+i;
            }
        }
    }
    if(a>b && b>=0)
    {
        for(i=b+1; i<a; i++)
        {
            if(i%2!=0)
            {
                sum=sum+i;
            }
        }
    }

    if(b>a && a<0)
    {
        for(i=a+1; i<b; i++)
        {
            if(i%2!=0)
            {
                sum=sum+i;
            }
        }
    }

    if(b>a && a>=0)
    {
        for(i=a+1; i<b; i++)
        {
            if(i%2!=0)
            {
                sum=sum+i;
            }
        }
    }
    printf("%d\n",sum);
    return 0;
}
