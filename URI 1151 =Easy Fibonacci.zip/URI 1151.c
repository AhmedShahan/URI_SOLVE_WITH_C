#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n,i;
    scanf("%d",&n);

    int a=0,b=1,c;
    printf("%d",a);
    c=a+b;
    for(i=1; i<=n-1; i++)
    {
        printf(" %d",c);
        c=a+b;
        a=b;
        b=c;
    }
    printf("\n");
    return 0;
}
