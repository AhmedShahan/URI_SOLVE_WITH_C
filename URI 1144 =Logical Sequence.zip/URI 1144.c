#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n;
    scanf("%d",&n);
    int i=0;
    int a=1;
    while(i!=n)
    {
        printf("%d %d %d\n",a,a*a,a*a*a);
        printf("%d %d %d\n",a,a*a+1,a*a*a+1);
        i++;
        a++;
    }
}
