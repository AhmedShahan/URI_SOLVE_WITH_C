#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a,b;

    while(1)
    {
        scanf("%d %d",&a,&b);
        if(a==b)
        {
            break;
            printf("\n");
        }
        else
        {
            if(b>a)
            {
                printf("Crescente\n");
            }
            else
            {
                printf("Decrescente\n");
            }
        }
    }




}
