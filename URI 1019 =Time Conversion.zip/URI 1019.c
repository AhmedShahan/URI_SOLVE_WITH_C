#include <stdio.h>
#include <stdlib.h>

int main()
{
    int sIn,h,i,m,sOut;
    scanf("%d",&sIn);
    h=sIn/3600;
    i=sIn%3600;
    m=i/60;
    sOut=i%60;
    printf("%d:%d:%d\n",h,m,sOut);
    return 0;
}
