#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n,a,b,sum=0;
    scanf("%d",&n);
    int i=0,j;
    while (i!=n)
    {
        scanf("%d %d",&a,&b);
        if(a>b)
        {
            for(j=b+1; j<=a-1; j++)
            {
                if(j%2!=0)
                {
                    sum=sum+j;
                }
            }
        }
        else
        {
            for(j=a+1; j<=b-1; j++)
            {
                if(j%2!=0)
                {
                    sum=sum+j;
                }
            }
        }
        printf("%d\n",sum);
        i++;
        sum=0;
    }
}
