#include <stdio.h>
#include <stdlib.h>
int Int=0,Jer=0,drow=0;
int res(number)
{
    int i,j;
    if(number==1)
    {
    scanf("%d %d",&i,&j);
    if(i>j)
    {
        Int++;
    }
    else if(i<j)
    {
        Jer++;
    }
    else
    {
        drow++;
    }
    }
    else
    {
    printf("Inter:%d\n",Int);
    printf("Gremio:%d\n",Jer);
    printf("Empates:%d\n",drow);
    if(Int>Jer)
    {
        printf("Inter venceu mais\n");
    }
    else if(Int<Jer)
    {
        printf("Gremio venceu mais\n");
    }
    else
    {
        printf("N�o houve vencedor\n");
    }
    }
}


int main()
{
    res(1);
    int x,n=1;
    while(x!=2)
    {
        printf("Novo grenal (1-sim 2-nao)\n");
        scanf("%d",&x);
        if(x==1)
        {
            n++;
            res(1);
        }
    }
    printf("%d grenais\n",n);
    res(2);
}
