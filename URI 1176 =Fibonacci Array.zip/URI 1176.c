#include <stdio.h>
#include <stdlib.h>
int main()
{
    long long int ser[60];
    ser[0]=0;
    ser[1]=1;
    int i;
    for(i=2; i<61; i++)
    {
        ser[i]=ser[i-1]+ser[i-2];
    }

    int input,j=0,a;
    scanf("%d",&input);

    while(j!=input)
    {
        scanf("%d",&a);
        printf("Fib(%d) = %lld\n",a,ser[a]);
        j++;
    }
}
